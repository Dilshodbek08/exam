clear all
clc
x=input('Kasallikka moyillar sonini kiriting: ');
y=input('Kasallanganlar sonini kiriting: ');
z=input('Kasallikka moyilmaslar sonini kiriting: ');
B_one=input('Kontaklar chastotasini kiriting(kritik nuqtadan past holat): ');
B_two=input('Kontaklar chastotasini kiriting(kritik nuqtadan yuqori holat): ');
G_one=input('Moyilmaslik chastotasini kiriting(kritik nuqtadan past holat): ');
G_two=input('Moyilmaslik chastotasini kiriting(kritik nuqtadan past holat): ');
nyu=input('Tashqaridan moyillik soni: ');
critic=input('Kassallanishning kiritik nuqtasi: ');
T=input('Kuzatish vaqtini kiriting: ');

for i=1:T
    vaqt(i)=i;
    if y(i)<=critic
      x(i+1)=x(i)-B_one*x(i)*y(i)+nyu;
      y(i+1)=y(i)+B_one*x(i)*y(i)-G_one*y(i);
      z(i+1)=z(i)+G_one*y(i)-nyu;
    else
      x(i+1)=x(i)-B_two*x(i)*y(i)+nyu;
      y(i+1)=y(i)+B_two*x(i)*y(i)-G_two*y(i);
      z(i+1)=z(i)+G_two*y(i)-nyu; 
    end
end
vaqt(i+1)=i+1;
fprintf('Kasallikka moyillar soni: %f\n',x(T+1));
fprintf('Kasallanganlar soni: %f\n',y(T+1));
fprintf('Kasallikka moyilmaslar soni: %f\n',z(T+1));
plot(vaqt,x,'*');
hold on;
plot(vaqt,y,'--');
hold on;
plot(vaqt,z,':');
title('Epidemiya grafigi');
legend('Kasallikka moyillar soni','Kasallanganlar soni','Kasallikka moyilmaslar soni');